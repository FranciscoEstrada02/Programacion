package e3;

public interface IMitosizable {

}
