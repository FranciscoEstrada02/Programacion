package e3;

public class Bug extends Comun {

    public Bug(String nombre, int coste, int ataque, int defensa, int velocidad){
        super(nombre,coste, ataque, defensa, velocidad);
    }
}
