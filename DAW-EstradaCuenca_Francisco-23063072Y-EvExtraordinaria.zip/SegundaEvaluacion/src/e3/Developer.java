package e3;

public class Developer extends Comun{

    public Developer(String nombre, int coste, int ataque, int defensa, int velocidad){
        super(nombre,coste, ataque, defensa, velocidad);
    }

}
